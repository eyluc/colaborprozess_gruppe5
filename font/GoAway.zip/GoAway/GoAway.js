/*---------------------*/
/*---- Insert CSS -----*/
var head = document.getElementsByTagName('head')[0];
var link = document.createElement('link');
link.rel = 'stylesheet';
link.type = 'text/css';
link.href = browser.runtime.getURL("GoAway.css");
link.media = 'all';
head.appendChild(link);

var keywords = [];//default keywords werden im background script gesetzt
let select ;
let momentum = [];
let elements = [];
let isLoopRunning = false;
const distanz = 100;
let step = 0;

let mouse = { x: 0, y: 0 };
document.addEventListener('mousemove', (event) => {
  mouse = { x: event.clientX, y: event.clientY };
});

/*--------content script asks background script to get the current keywords -------*/

setInterval(() => {
  browser.runtime.sendMessage('getkeywords', (response) => {
    //console.log('Keywords:', response);
    if (keywords.length != response.length) {
      keywords = response;

      //---parse Text again, restart process because keywords have changed 
      colorizeText(document.body);
      step=0;
      init();
      isLoopRunning = false;

      if (!isLoopRunning) {
        isLoopRunning = true;
        loop();
      }

    }

  });
}, 1000); // Adjust the interval as needed


function getScrollDistance() {
  var scrollDistance = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
  console.log('Scroll-Distanz:', scrollDistance);
  return scrollDistance;
}

window.addEventListener('scroll', function () {
  const scrollDistance = getScrollDistance(); // Abrufen der Scroll-Distanz

  /*for (let i = 0; i < select.length; i++) {
    select[i].style.top =  -1* scrollDistance + 'px'; // Setzen der neuen Position
    momentum[i].pos.scrollY = -1* scrollDistance;
    momentum[i].pos.y = -1* scrollDistance;
  }*/
});


function colorizeText(node) {
  if (node.nodeType === Node.TEXT_NODE) {
    var text = node.textContent;
    var replacedText = text;
    for (var i = 0; i < keywords.length; i++) {
      var keyword = keywords[i];
      if (text.includes(keyword)) {
        replacedText = replacedText.replace(new RegExp(keyword, 'g'), '<span class="white" >' + keyword + '</span><span class="keyword" >' + keyword + '</span>');

      }
    }
    if (replacedText !== text) {
      var span = document.createElement('span');
      span.innerHTML = replacedText;
      node.parentNode.replaceChild(span, node);
    }
  } else {
    for (var j = 0; j < node.childNodes.length; j++) {
      colorizeText(node.childNodes[j]);
    }
  }
}


colorizeText(document.body);
init();
if (!isLoopRunning) {
  isLoopRunning = true;
  loop();
}








function init() {
  momentum = [];
  elements = [];
  select = document.getElementsByClassName("keyword");
  for (let i = 0; i < select.length; i++) {
    let bounds = select[i].getBoundingClientRect();

    select[i].style.top = "0px";
    select[i].style.left = -1 * bounds.width + "px";

    select[i].style.position = "fixed";
    elements.push(select[i]);
    momentum.push({ pos: { x: bounds.x, y: bounds.y, scrollY: 0 }, speed: { x: 0, y: 0 } });

    //momentum.push({ pos: { x: Math.random() * 100, y: Math.random() * 100 }, speed: { x: 0, y: 0 } });
  }


}




function distance(a, b) {
  var aa = a.x - b.x;
  var bb = a.y - b.y;
  return Math.sqrt(aa * aa + bb * bb);
}



function loop() {

  for (let i = 0; i < elements.length; i++) {

    if (distance(mouse, momentum[i].pos) < distanz) {
      momentum[i].speed.x += ((momentum[i].pos.x - mouse.x)) / 200;
      momentum[i].speed.y += ((momentum[i].pos.y - mouse.y)) / 200;
    }
    elements[i].style.transform = "translateX(" + (momentum[i].pos.x) + "px) translateY(" + (momentum[i].pos.y) + "px) rotate(" + (Math.abs(momentum[i].speed.y) * Math.abs(momentum[i].speed.x) * 10) + "deg)";

    momentum[i].pos.x += momentum[i].speed.x;
    momentum[i].pos.y += momentum[i].speed.y;

    momentum[i].speed.x *= 0.98;
    momentum[i].speed.y *= 0.98;

  }

  step++;
  if (isLoopRunning) {
    requestAnimationFrame(loop);
  }
}




