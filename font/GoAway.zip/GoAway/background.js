// Event-Listener für das Klicken der Browsererweiterung
chrome.browserAction.onClicked.addListener(function(tab) {
    // Öffnen des Pop-up-Fensters
    chrome.windows.create({
      url: chrome.runtime.getURL("popup.html"),
      type: "popup",
      width: 450,
      height: 250
    });
  });
  
 var keywords=['HSLU', 'Hochschule'] ;

 chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.data) {//message kommt von popup.js
    const value = message.data;
    const l=keywords.length;
    keywords[l]=value;
    
  }
  if (message === 'getkeywords') {//message kommt von content.js, fragt nach keywords
    sendResponse(keywords);
  }
});
