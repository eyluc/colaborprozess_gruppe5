function handleButtonClick() {
    var input = document.getElementById("myInput");
    var word = input.value;
    console.log("Eingegebenes Wort:", word);
    // Hier können Sie weitere Aktionen mit dem eingegebenen Wort durchführen
    browser.runtime.sendMessage({ data: word });//an background script schicken
  }
  
  document.getElementById("submitButton").addEventListener("click", handleButtonClick);
  